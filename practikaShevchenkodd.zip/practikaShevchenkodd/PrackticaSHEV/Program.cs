﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Configuration;
using MySql.Data.MySqlClient;
using System.Data.SqlClient;
using System.Globalization;

namespace ApacheLogAggregator
{
    class Program
    {
        private static string logDirectory;
        private static string logMask;
        private static string dbConnectionString;

        static void Main(string[] args)
        {
            
            LoadConfiguration();

            
            var logFiles = Directory.GetFiles(logDirectory, logMask, SearchOption.TopDirectoryOnly);
            var logParser = new ApacheLogParser();
            var logEntries = new List<ApacheLogEntry>();

            foreach (var logFile in logFiles)
            {
                using (var fs = new FileStream(logFile, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
                {
                    var entries = logParser.Parse(fs);
                    logEntries.AddRange(entries);
                }
            }

            
            if (logEntries.Count > 0)
            {
                using (var connection = new MySqlConnection(dbConnectionString))
                {
                    connection.Open();

                    var command = new MySqlCommand();
                    command.Connection = connection;

                    foreach (var entry in logEntries)
                    {
                        command.CommandText = @"INSERT INTO apache_logs(ip_address, timestamp, request_method, request_url, http_protocol, response_code, response_size, user_agent) 
                                                VALUES(@ip_address, @timestamp, @method, @url, @protocol, @code, @size, @user_agent)";

                        command.Parameters.AddWithValue("@ip_address", entry.IPAddress);
                        command.Parameters.AddWithValue("@timestamp", entry.Timestamp);
                        command.Parameters.AddWithValue("@method", entry.RequestMethod);
                        command.Parameters.AddWithValue("@url", entry.RequestURL);
                        command.Parameters.AddWithValue("@protocol", entry.HttpProtocol);
                        command.Parameters.AddWithValue("@code", entry.ResponseCode);
                        command.Parameters.AddWithValue("@size", entry.ResponseSize);
                        command.Parameters.AddWithValue("@user_agent", entry.UserAgent);

                        command.ExecuteNonQuery();

                        command.Parameters.Clear();
                    }
                }
            }

            
            DisplayLogs();
        }

        private static void LoadConfiguration()
        {
            logDirectory = ConfigurationManager.AppSettings["LogDirectory"];
            logMask = ConfigurationManager.AppSettings["LogMask"];
            dbConnectionString = ConfigurationManager.AppSettings["DBConnectionString"];
        }

        private static void DisplayLogs()
        {
            Console.WriteLine("Please select grouping option:\n1. Group by IP Address\n2. Group by date\n3. Select logs within date range\n");
            int menuOption = Convert.ToInt32(Console.ReadLine());

            switch (menuOption)
            {
                case 1:
                    DisplayLogsByIP();
                    break;
                case 2:
                    DisplayLogsByDate();
                    break;
                case 3:
                    DisplayLogsByDateRange();
                    break;
                default:
                    Console.WriteLine("Invalid option.");
                    break;
            }
        }

        private static void DisplayLogsByIP()
        {
            using (var connection = new MySqlConnection(dbConnectionString))
            {
                connection.Open();

                var command = new MySqlCommand();
                command.Connection = connection;
                command.CommandText = @"SELECT ip_address, COUNT(*) as request_count FROM apache_logs GROUP BY ip_address ORDER BY request_count DESC";

                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        Console.WriteLine("{0}: {1}", reader.GetString(0), reader.GetInt32(1));
                    }
                }
            }
        }

        private static void DisplayLogsByDate()
        {
            using (var connection = new MySqlConnection(dbConnectionString))
            {
                connection.Open();

                var command = new MySqlCommand();
                command.Connection = connection;
                command.CommandText = @"SELECT DATE_FORMAT(timestamp, '%Y-%m-%d') as date, COUNT(*) as request_count FROM apache_logs GROUP BY date ORDER BY date DESC";

                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        Console.WriteLine("{0}: {1}", reader.GetString(0), reader.GetInt32(1));
                    }
                }
            }
        }

        private static void DisplayLogsByDateRange()
        {
            Console.WriteLine("Please enter start date (yyyy-MM-dd): ");
            DateTime startDate = Convert.ToDateTime(Console.ReadLine());
            Console.WriteLine("Please enter end date (yyyy-MM-dd): ");
            DateTime endDate = Convert.ToDateTime(Console.ReadLine());

            using (var connection = new MySqlConnection(dbConnectionString))
            {
                connection.Open();

                var command = new MySqlCommand();
                command.Connection = connection;
                command.CommandText = @"SELECT * FROM apache_logs WHERE timestamp >= @start_time AND timestamp <= @end_time";
                command.Parameters.AddWithValue("@start_time", startDate);
                command.Parameters.AddWithValue("@end_time", endDate);

                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        Console.WriteLine("{0} {1} {2} {3} {4} {5} {6} {7}", reader.GetString(1), reader.GetDateTime(2), reader.GetString(3), reader.GetString(4), reader.GetString(5), reader.GetInt32(6), reader.GetInt32(7), reader.GetString(8));
                    }
                }
            }
        }
    }

    class ApacheLogEntry
    {
        public string IPAddress { get; set; }
        public DateTime Timestamp { get; set; }
        public string RequestMethod { get; set; }
        public string RequestURL { get; set; }
        public string HttpProtocol { get; set; }
        public int ResponseCode { get; set; }
        public int ResponseSize { get; set; }
        public string UserAgent { get; set; }
    }

    class ApacheLogParser
    {
        public List<ApacheLogEntry> Parse(Stream inputStream)
        {
            var entries = new List<ApacheLogEntry>();

            using (var reader = new StreamReader(inputStream))
            {
                while (!reader.EndOfStream)
                {
                    var line = reader.ReadLine();

                    
                    var timestampFormat = "dd/MMM/yyyy:HH:mm:ss zzz";
                    var inputTimezone = TimeZoneInfo.Utc;
                    var outputTimezone = TimeZoneInfo.Local;

                    var parts = line.Split(' ');
                    var ipAddress = parts[0];
                    var timestamp = DateTimeOffset.ParseExact(parts[3] + " " + parts[4], "[" + timestampFormat + "]", CultureInfo.InvariantCulture, DateTimeStyles.AssumeUniversal).DateTime;
                    timestamp = TimeZoneInfo.ConvertTimeFromUtc(timestamp, inputTimezone).AddHours(outputTimezone.BaseUtcOffset.Hours);
                    var requestMethod = parts[5].Substring(1);
                    var requestUrl = parts[6];
                    var httpProtocol = parts[7];
                    var responseCode = int.Parse(parts[8]);
   
                    var userAgent = parts[11].Substring(1).Replace("\"", "");

                   
                    var entry = new ApacheLogEntry()
                    {
                        IPAddress = ipAddress,
                        Timestamp = timestamp,
                        RequestMethod = requestMethod,
                        RequestURL = requestUrl,
                        HttpProtocol = httpProtocol,
                        ResponseCode = responseCode,
                       
                        UserAgent = userAgent
                    };

                    entries.Add(entry);
                }
            }

            return entries;
        }
    }
}